a = input("Please type your name:")
while a != "your name":
  a = input("Please type your name:")
print("Thanks!")